from django.apps import AppConfig


class AitraderConfig(AppConfig):
    name = 'aitrader'
